package com.example.yashmankarproductsassignment.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;

import com.example.yashmankarproductsassignment.R;
import com.example.yashmankarproductsassignment.adapters.ProductAdapter;
import com.example.yashmankarproductsassignment.model.Product;
import com.example.yashmankarproductsassignment.viewmodels.ProductViewModel;

import java.util.ArrayList;
import java.util.List;

public class ProductListActivity extends AppCompatActivity {
    private ProductViewModel viewModel;
    private ProductAdapter adapter;
    private List<Product> productList;
    private Dialog loadingDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activty_product_list);

        viewModel = new ViewModelProvider(this).get(ProductViewModel.class);
        productList = new ArrayList<>();

        //Set first item as a title
        Product product = new Product();
        product.setTitle("Products List");
        productList.add(product);

        RecyclerView recyclerView = findViewById(R.id.recyclerViewProducts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProductAdapter(productList, new ProductAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Product product) {
                Intent intent = new Intent(ProductListActivity.this, ProductDetailsActivity.class);
                intent.putExtra("productTitle", product.getTitle());
                intent.putExtra("productDescription", product.getDescription());
                String imgUrl = "No Image";
                if (!product.getImages().isEmpty())
                    imgUrl = product.getImages().get(0);

                intent.putExtra("image", imgUrl);
                startActivity(intent);
            }
        });
        recyclerView.setAdapter(adapter);

        setupLoadingDialog();

        viewModel.getProducts().observe(this, new Observer<List<Product>>() {
            @Override
            public void onChanged(List<Product> products) {
                hideLoadingDialog();
                productList.addAll(products);
                adapter.notifyDataSetChanged();
            }
        });

        showLoadingDialog();
        viewModel.fetchProducts();

    }

    private void setupLoadingDialog() {
        loadingDialog = new Dialog(this);
        loadingDialog.setContentView(R.layout.dialog_loading);
        loadingDialog.setCancelable(false);
    }

    private void showLoadingDialog() {
        if (!loadingDialog.isShowing()) {
            loadingDialog.show();
        }
    }

    private void hideLoadingDialog() {
        if (loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }
    }

}