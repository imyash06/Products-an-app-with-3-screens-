package com.example.yashmankarproductsassignment.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.bumptech.glide.Glide;
import com.example.yashmankarproductsassignment.R;
import com.example.yashmankarproductsassignment.model.Product;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_TITLE = 0;
    private static final int TYPE_PRODUCT = 1;

    private List<Product> items;
    private OnItemClickListener clickListener;

    public interface OnItemClickListener {
        void onItemClick(Product product);
    }

    public ProductAdapter(List<Product> items, OnItemClickListener clickListener) {
        this.items = items;
        this.clickListener = clickListener;
    }

    @Override
    public int getItemViewType(int position) {
        return position == 0 ? TYPE_TITLE : TYPE_PRODUCT;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_TITLE) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_title, parent, false);
            return new TitleViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
            return new ProductViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof TitleViewHolder) {
            ((TitleViewHolder) holder).bind("Products List");
        } else if (holder instanceof ProductViewHolder) {
            Product product = (Product) items.get(position);
            ((ProductViewHolder) holder).bind(product, clickListener);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class TitleViewHolder extends RecyclerView.ViewHolder {
        private TextView titleTextView;

        public TitleViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.titleTextView);
        }

        public void bind(String title) {
            titleTextView.setText(title);
        }
    }

    static class ProductViewHolder extends RecyclerView.ViewHolder {
        private TextView tvTitle;
        private TextView tvDescription;
        private ImageView imgProduct;
        String imgUrl = "No url";

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tvTitle);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            imgProduct = itemView.findViewById(R.id.imgProduct);
        }

        public void bind(final Product product, final OnItemClickListener clickListener) {
            tvTitle.setText(product.getTitle());
            tvDescription.setText(product.getDescription());

            if (!product.getImages().isEmpty())
                imgUrl = product.getImages().get(0);

            Glide.with(imgProduct)
                    .load(imgUrl)
                    .placeholder(R.drawable.ic_img_default_placeholder)
                    .centerCrop()
                    .into(imgProduct);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickListener.onItemClick(product);
                }
            });
        }
    }
}