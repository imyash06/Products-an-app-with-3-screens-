package com.example.yashmankarproductsassignment.viewmodels;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.yashmankarproductsassignment.model.Product;
import com.example.yashmankarproductsassignment.model.ProjectMasterModel;
import com.example.yashmankarproductsassignment.restApis.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.List;

public class ProductViewModel extends ViewModel {
    private MutableLiveData<List<Product>> products;
    private ApiService apiService;

    public ProductViewModel() {
        products = new MutableLiveData<>();
        apiService = ApiService.Factory.create();
    }

    public LiveData<List<Product>> getProducts() {
        return products;
    }

    public void fetchProducts() {
        apiService.getProducts().enqueue(new Callback<ProjectMasterModel>() {
            @Override
            public void onResponse(Call<ProjectMasterModel> call, Response<ProjectMasterModel> response) {
                if (response.isSuccessful() && response.body() != null) {
                    products.setValue(response.body().getProducts());
                }
            }

            @Override
            public void onFailure(Call<ProjectMasterModel> call, Throwable t) {
                // Handle failure
            }
        });
    }
}