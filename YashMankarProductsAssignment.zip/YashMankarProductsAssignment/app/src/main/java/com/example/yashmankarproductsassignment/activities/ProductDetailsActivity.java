package com.example.yashmankarproductsassignment.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.yashmankarproductsassignment.R;

public class ProductDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        TextView tvTitle = findViewById(R.id.tvTitle);
        TextView tvDescription = findViewById(R.id.tvDescription);
        ImageView imgBack = findViewById(R.id.imgBack);
        ImageView imgProductDetail = findViewById(R.id.imgProductDetail);

        String title = getIntent().getStringExtra("productTitle");
        String description = getIntent().getStringExtra("productDescription");
        String image = getIntent().getStringExtra("image");

        tvTitle.setText(title);
        tvDescription.setText(description);

        Glide.with(imgProductDetail)
                .load(image)
                .placeholder(R.drawable.ic_img_default_placeholder)
                .centerCrop()
                .into(imgProductDetail);


        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}