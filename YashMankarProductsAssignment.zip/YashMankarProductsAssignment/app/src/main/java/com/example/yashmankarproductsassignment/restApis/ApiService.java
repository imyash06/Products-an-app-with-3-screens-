package com.example.yashmankarproductsassignment.restApis;

import com.example.yashmankarproductsassignment.model.ProjectMasterModel;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;

public interface ApiService {
    @GET("products")
    Call<ProjectMasterModel> getProducts();

    class Factory {
        private static final String BASE_URL = "https://dummyjson.com/";

        public static ApiService create() {

            HttpLoggingInterceptor logLevel = new HttpLoggingInterceptor();
            logLevel.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
            httpClient.addInterceptor(logLevel);
            httpClient.connectTimeout(120, TimeUnit.SECONDS);
            httpClient.readTimeout(120, TimeUnit.SECONDS);
            httpClient.writeTimeout(120, TimeUnit.SECONDS);
            httpClient.retryOnConnectionFailure(true);

            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(httpClient.build())
                    .build();
            return retrofit.create(ApiService.class);
        }
    }
}